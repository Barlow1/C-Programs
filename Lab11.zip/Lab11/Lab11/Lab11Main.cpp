/*Christian Barlow
CS201L
Lab11
*/
#include <string>
#include <iostream>
#include <fstream>
using namespace std;
template <class T>
void mySwap(T arr[], int first, int second) {
	//swaps two values in an array
	T temp;
	temp = arr[first];
	arr[first] = arr[second];
	arr[second] = temp;
}

template <class T>
T myMin(T arr[]) {
	//find min value and return it
	T min = arr[0];
	for (int i = 0; i < 100; i++) { //search for min val
		if (arr[i] < min) {
			min = arr[i];
		}
	}
	return min;
}

template <class T>
T myMax(T arr[]) {
	//find max value and return it
	T max = arr[0];
	for (int i = 0; i < 100; i++) { //seardch for max val
		if (arr[i] > max) {
			max = arr[i];
		}
	}
	return max;
}

template <class T>
int mySearch(T arr[], T target) {
	//search for index of target in array
	bool found = false;
	for (int i = 0; i < 100; i++) { //search for target in array
		if (arr[i] == target) {
			return i;
			found = true; //change to found
			break;//stops loop
		}
	}
	if (!found) { //return -1 if target is not in array
		return -1;
	}
}
int main() {
	//file streams
	ifstream integers("integers.txt");
	ifstream doubles("doubles.txt");
	ifstream strings("strings.txt");
	ofstream fout("output.txt");
	
	if (integers.good() == false) { //prints error if file not found
		cout << "Error opening file!" << endl;
		system("pause");
		return 0;
	}
	if (doubles.good() == false) { //prints error if file not found
		cout << "Error opening file!" << endl;
		system("pause");
		return 0;
	}
	if (strings.good() == false) { //prints error if file not found
		cout << "Error opening file!" << endl;
		system("pause");
		return 0;
	}
	//create arrays
	int integerArr[100];
	string stringArr[100];
	double doubleArr[100];
	
	//fill arrays with data from text files
	for (int i = 0; i < 100; i++) {
		integers >> integerArr[i];
		doubles >> doubleArr[i];
		strings >> stringArr[i];
	}

	//Output
	fout << "Integers:" << endl << "Swapped items at positions 10 and 20\nBefore: [10] " << integerArr[10] << " [20] " << integerArr[20] << endl;
	mySwap(integerArr, 10, 20); //swap values at 10 and 20
	fout << "After: [10] " << integerArr[10] << " [20] " << integerArr[20] << endl; //print out new values
	fout << "Minimum: " << myMin(integerArr) << endl; 
	fout << "Maximum: " << myMax(integerArr) << endl;
	fout << "The number 1 is at position " << mySearch(integerArr, 1) << endl; 
	fout << "The number 5 is at position " << mySearch(integerArr, 5) << endl << endl;

	fout << "Doubles:" << endl << "Swapped items at positions 10 and 20\nBefore: [10] " << doubleArr[10] << " [20] " << doubleArr[20] << endl;
	mySwap(doubleArr, 10, 20); //swap values at 10 and 20
	fout << "After: [10] " << doubleArr[10] << " [20] " << doubleArr[20] << endl; //print out new values
	fout << "Minimum: " << myMin(doubleArr) << endl;
	fout << "Maximum: " << myMax(doubleArr) << endl;
	fout << "The number 4.62557 is at position " << mySearch(doubleArr, 4.62557) << endl;
	fout << "The number 1.23456 is at position " << mySearch(doubleArr, 1.23456) << endl << endl;

	fout << "Strings:" << endl << "Swapped items at positions 10 and 20\nBefore: [10] " << stringArr[10] << " [20] " << stringArr[20] << endl;
	mySwap(stringArr, 10, 20); //swap values at 10 and 20
	fout << "After: [10] " << stringArr[10] << " [20] " << stringArr[20] << endl; //print out new values
	fout << "Minimum: " << myMin(stringArr) << endl;
	fout << "Maximum: " << myMax(stringArr) << endl;
	string shoes = "Shoes";
	fout << "The word Shoes is at position " << mySearch(stringArr, shoes) << endl;
	string pumpkin = "Pumpkin";
	fout << "The word Pumpkin is at position " << mySearch(stringArr, pumpkin) << endl;

	/*//original array
	for (int j = 0; j < 100; j++) {
		cout << integerArr[j] << " ";
	}

	cout << endl;

	mySwap(integerArr, 0, 1);

	for (int j = 0; j < 100; j++) {
		cout << integerArr[j] << " ";
	}

	cout << endl;
	cout << "Min: " << myMin(integerArr) << endl;
	cout << "Max: " << myMax(integerArr) << endl;
	*/

	integers.close();
	doubles.close();
	strings.close();
	fout.close();

	cout << "Finished!" << endl; //output to user that it is finished
	system("pause");

	return 0;
}