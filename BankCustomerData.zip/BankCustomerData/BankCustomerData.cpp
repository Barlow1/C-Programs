//Christian Barlow
//February 16, 2018
//Bank Customer Data Assignment 2
// ALGORITHM
/*open file
initialize arrays, variables
while not at end file
	output menu
	if input == 1
		print all customers data(for i in array1, array2, array3, array4 print arrayN[i])
	if input == 2
		print all names and ID's(for i in array1, array2 print arrayN[i])
	if input == 3
		print account totals(for i in array3, array4 print array3[i] + array4[i])
	if input == q or Q
		quit running


*/
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

using namespace std;

void printCustomerData(const int a[], const string b[], const string c[], const double d[], const double e[], int size);
//Takes input of 5 Arrays and the array size and outputs them under ID, First, last, savings, and checking.
void printCustomerData(const int a[],const string b[],const string c[],const double d[], const double e[], int size) {
	cout << setw(15) << left << "ID" << setw(15) << left << "First" << setw(15) << left << "Last" << setw(30) << left << "Savings Account" << setw(30) << left << "Checking Account" << endl;
	for (int k = 0; k < 105; k++) {
		cout << "=";
	}
	cout << endl;
	for (int j = 0; j < size; j++) {
		cout << setw(15) << left << a[j] << setw(15) << left << b[j] << setw(15) << left << c[j] << setw(30) << left << d[j] << setw(30) << left << e[j] << endl;
	}
}

void printNames(const int id[], const string first[], const string last[], int size);
//Takes input of 3 Arrays and the  int array size and outputs them under ID, First, last.
void printNames(const int id[], const string first[], const string last[], int size){
	cout << setw(15) << left << "ID" << setw(15) << left << "First" << setw(15) << left << "Last" << endl;
	for (int k = 0; k < 40; k++) {
		cout << "=";
	}
	cout << endl;
	for (int j = 0; j < size; j++) {
		cout << setw(15) << left << id[j] << setw(15) << left << first[j] << setw(15) << left << last[j] << endl;

	}
}


void printTotal(const int id[], const double savings_Account[], const double checking_Account[], int size);
//Takes input of 3 Arrays and the array size and outputs them under ID, savings, and checking and outputs the sum of checking and saving
void printTotal(const int id[], const double savings_account[], const double checking_account[], int size) {
	cout << setw(15) << left << "ID" << setw(30) << left << "Savings Account" << setw(30) << left << "Checking Account" << setw(15) << left << "Total" << endl;
	for (int k = 0; k < 95; k++) {
		cout << "=";
	}
	cout << endl;
	for (int j = 0; j < size; j++) {
		cout << setw(15) << left << id[j] << setw(30) << left << savings_account[j] << setw(30) << left << checking_account[j] << setw(15) << left << (savings_account[j] + checking_account[j]) << endl;

	}
}

int main(){
	ifstream fin("input.txt");
	if (fin.fail()) { //Makes sure file is read correctly
		cout << "Error couldn't find file!";
	}
	const int ArrSize = 10;
	int IDArr[ArrSize];
	string FirstArr[ArrSize];
	string LastArr[ArrSize];
	double CheckArr[ArrSize];
	double SaveArr[ArrSize];
	int i = 0;
	char input = '0';

	while(fin.good()) { //read in customer data into 5 different arrays until end of file
			fin >> IDArr[i] >> FirstArr[i] >> LastArr[i] >> CheckArr[i] >> SaveArr[i];
			i++;
		}
	while (true) { //Outputs menu and has cutomer choose which funtion they would like to preform
		//Handles invalid input and quits the program if user enters q
		cout << "1. Print all customer data\n2."
			<< " Print names and IDs\n3.print account totals\n4.Enter q or Q to quit\n";
		cout << "Enter Choice or q to quit: ";
		cin >> input;
		switch (input) {
		case '1':
			printCustomerData(IDArr, FirstArr, LastArr, CheckArr, SaveArr, ArrSize);
			break;
		case '2':
			printNames(IDArr, FirstArr, LastArr, ArrSize);
			break;
		case '3':
			printTotal(IDArr, SaveArr, CheckArr, ArrSize);
			break;
		case 'q':
		case 'Q':
			cout << "Thanks for using our program!";
			exit(1);
		default:
			cout << "\nYour input was invalid\n\n";
			break;
		}
	}
	return 0;
}