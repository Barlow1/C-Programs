#pragma once
// Christian Barlow
// May 4, 2018
// Exam 2

#include <string>
using namespace std;

#ifndef EMPLOYEE_H
#define EMPLOYEE_H


class Employee
{
private:
	string name;
	double balance;
	double payRate;
	bool employed;

public:
	// Constructor
	Employee(string myName = "")
	{
		name = myName;
		balance = 0;
		payRate = 10.00;
		employed = true;
	}

	// Getter to return the current pay rate
	double getPayRate()
	{
		return payRate;
	}

	// Getter to return the current amount of pay earned
	double getBalance()
	{
		return balance;
	}

	// Getter to get Employee's name
	string getName()
	{
		return name;
	}

	// Function to give the raise. It takes in a percent in whole numbers 
	// (ex: 5 for 5%)
	void giveRaise(int rate)
	{
		double decimal = rate * .01;
		payRate = payRate + (payRate * decimal);
	}

	// Pays the employee
	void pay()
	{
		balance += payRate;
	}

	// Fires the Employee
	void fire()
	{
		employed = false;
	}

	// Returns if the Employee is currently employed
	bool isEmployed()
	{
		return employed;
	}

};

#endif