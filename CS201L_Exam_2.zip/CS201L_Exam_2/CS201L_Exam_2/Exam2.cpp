// Chrtistian Barlow
// May 4, 2018
// Exam 2

#include "Employee.h"
#include <iostream>
#include <utility>
#include <map>
#include <fstream>
using namespace std;

int main() {
	//creates fixed decimal; point of two decimal places
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(2);
	
	string command;
	int idNum;
	string firstName;
	string lastName;
	string fullName;
	int raisePercent;

	map<int, Employee> EmployeePayRoll; //creates map with id number and an employee object

	//input and output files
	ifstream fin("input.txt");
	ofstream fout("output.txt");

	if (!fin.good()) { //if error opening file, send error to user
		cerr << "There was an error opening the input file";
		system("pause");
		return 0;
	}

	while (fin.good()) { //while there is content in input
		command = "";
		idNum = 0;
		firstName = "";
		lastName = "";
		fullName = "";
		raisePercent = 0;
		fin >> command;
		if (command == "NEW") { //if it is a new employee
			fin >> idNum; //read in variables for new employee
			fin >> firstName;
			fin >> lastName;
			fullName = firstName + " " + lastName; //create full name 

			Employee newEmployee = Employee(fullName) ; //creates new employee object

			//creates pair of id number and employee and inserts it into the payroll map;
			pair<int, Employee> employeePair;
			employeePair.first = idNum;
			employeePair.second = newEmployee;
			EmployeePayRoll.insert(employeePair);

		}
		else if(command == "RAISE"){ //if command is raise
			fin >> idNum;
			fin >> raisePercent;
			// will search payroll for matching id number and will call give raise to that employee
			EmployeePayRoll.find(idNum)->second.giveRaise(raisePercent); 
		}
		else if (command == "PAY") {
			map<int, Employee>::iterator iter; //create iterator and pay every employee in EmployeePayRoll
			for (iter = EmployeePayRoll.begin(); iter != EmployeePayRoll.end(); iter++) {
				if (iter->second.isEmployed()) { //checks to make sure they are current employee
					iter->second.pay(); //adds pay rate to employee balance
				}
			}
		}
		else if (command == "FIRE") {
			fin >> idNum;
			EmployeePayRoll.find(idNum)->second.fire();

		}
	}



	map<int, Employee>::iterator iter;
	for (iter = EmployeePayRoll.begin(); iter != EmployeePayRoll.end(); iter++) { //iterates through map elements
		fout << iter->second.getName() << ", ID Number " << iter->first << ":" << endl; //ouputs namer and id number
		if (iter->second.isEmployed()) {
			fout << "Current pay rate: $" << iter->second.getPayRate() << endl; //if employed this will print current pay rate
		}
		else {
			fout << "Not employed with the company." << endl; //if not employed this print they are not employed
		}
		fout << "Pay earned to date: $" << iter->second.getBalance() << endl << endl; //will print  total balance of employee
}

	cout << "DONE!" << endl;

	system("pause");

	return 0;
}