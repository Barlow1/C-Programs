/*
Christian Barlow
CS201L
Lab 9 Problem C*/

#include "math.h"
#include <iostream>
#include <fstream>
using namespace std;

const double PI = 3.141592653589793;

double Area(int diameter) { //calculate area of pizza
	double area = (.25*PI*(pow(diameter, 2)));
	return area;
}

double Value(double area, double price) { //calculate price per square inch
	double value = (price / area);
	return value;
}

int main()
{
	//input and output diles
	ifstream fin("inputpizza.txt");
	ofstream fout("output.txt");

	//check if file is good, through error if not
	if (!fin)
	{
		cerr << "Error opening input file!";
		system("pause");
		return 1;
	}
	int options;
	int menuNumber = 0;
	double price; 
	int diameter;
	
	int *sizeArray; //will store diameters of pizza
	double *valueArray; //will store pizzas values
	int itemNumber = 0; //index for current pizza

		while (fin.good()) {
		fin >> options;

		menuNumber++;

		if (options <= 0) //dont look for more if no menu
			break;
		itemNumber = 0; //reset
		
		sizeArray = new int[options]; //set size of sizeArray
		valueArray = new double[options]; //set size of valueArray
		for (int i = 0; i < options; i++) {
			fin >> diameter;
			fin >> price;
			sizeArray[itemNumber] = diameter;
			valueArray[itemNumber] = Value(Area(diameter), price * 100); //price in cents
			itemNumber++;
		}
		int bestSize = sizeArray[0]; //initialize best values to first value
		double bestValue = valueArray[0];

		for (int i = 0; i < options; i++) {//iterate through items
			if (valueArray[i] < bestValue) { 
				bestValue = valueArray[i]; //sets pizza with best values
				bestSize = sizeArray[i];
			}
		}

		fout << "Menu " << menuNumber << ": " << bestSize << endl;

	}

	fin.close();
	fout.close();
	cout << "Done!" << endl;
	system("pause");

	return 0;
}