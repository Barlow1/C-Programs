// Melvin Boyd III
// 2 March 2018
// Lab 5/6 "Week 6 Program"

#include "stdafx.h"
#include "Fraction.h"
#include <iostream>
#include <string>
using namespace std;

// Find the greatest common denominator (GCD)
// For reducing
int Fraction::getGCD(int num1, int num2)
{
	int remainder = num2 % num1;
	if (remainder != 0)
		return getGCD(remainder, num1);
	return num1;
}

Fraction::Fraction()
{
	numerator = 0;
	denominator = 0;
}

// Reduce/simplify a fraction
void Fraction::reduce()
{
	if (denominator < 0) {
		denominator = -denominator;
		numerator = -numerator;
	}
	// Alter this function later to adjust for negative values
	int gcd = getGCD(numerator, denominator);

	numerator /= gcd;
	denominator /= gcd;
}

const Fraction Fraction::operator+(Fraction rhs)
{
	Fraction f;
	reduce();      // reduce this fraction
	rhs.reduce();  // reduce that fraction

				   // Find common terms, make new denom that common one
				   // Make numerator the addition of the two fractions
	f.denominator = denominator * rhs.denominator;
	f.numerator = (numerator * rhs.denominator) + (rhs.numerator * denominator);

	f.reduce();    // reduce new fraction
	return f;
}

const Fraction Fraction::operator-(Fraction rhs)
{
	Fraction f;
	reduce();		// Reduce this fraction
	rhs.reduce();	// Reduce that fraction

					// Find common terms, make new denom that common one
					// Make numerator the subtraction of the two fractions
	f.denominator = denominator * rhs.denominator;
	f.numerator = (numerator * rhs.denominator) - (rhs.numerator * denominator);

	f.reduce(); // Reduce new fraction
	return f;
}

const Fraction Fraction::operator*(Fraction rhs)
{
	Fraction f;
	reduce();		// Reduce this fraction
	rhs.reduce();	// Reduce that fraction

	f.denominator = denominator * rhs.denominator; // Multiply denominators
	f.numerator = numerator * rhs.numerator; // Multiply Numerators

	f.reduce(); // Reduce new fraction
	return f;
}

const Fraction Fraction::operator/(Fraction rhs)
{
	Fraction f;
	reduce();		// Reduce this fraction
	rhs.reduce();	// Reduce that fraction

	f.denominator = rhs.numerator; // Swap numerator and denominator
	f.numerator = rhs.denominator;

	f.denominator = denominator * f.denominator; // Multiply denominators
	f.numerator = numerator * f.numerator; // Multiply Numerators

	f.reduce(); // Reduce new fraction
	return f;
}

bool Fraction::operator==(Fraction rhs)
{
	reduce();
	rhs.reduce();
	if ((numerator == rhs.numerator) && (denominator == rhs.denominator))
		return true;
	return false;
}

bool Fraction::operator=(Fraction rhs)
{
	reduce();
	rhs.reduce();
	if ((numerator == rhs.numerator) && (denominator == rhs.denominator))
		return true;
	return false;
}

istream & operator>>(istream & input, Fraction & fract)
{
	input >> fract.numerator;
	char slash;
	input >> slash;
	input >> fract.denominator;
	return input;
}

ostream & operator<<(ostream & output, const Fraction & fract)
{
	output << fract.numerator << "/" << fract.denominator;
	return output;
}