// Melvin Boyd III
// 2 March 2018
// Lab 5/6 "Week 6 Program"

#include <iostream>
using namespace std;

class Fraction
{
private:
	//Declare two variables numerator & denominator
	int numerator;
	int denominator;
	int getGCD(int num1, int num2);

public:
	Fraction();
	void reduce();

	const Fraction operator+(Fraction rhs); // write declarartions for all math
	const Fraction operator-(Fraction rhs);
	const Fraction operator*(Fraction rhs);
	const Fraction operator/(Fraction rhs);

	bool operator==(Fraction rhs); // The instructions said to do the top one, the input file and code said to do the bottom
	bool operator=(Fraction rhs);

	friend ostream& operator<< (ostream& output, const Fraction& fract);
	friend istream& operator>> (istream& input, Fraction& fract);

};

